# Sckolar — Scramjet-ready frontend

This repository contains the Sckolar static frontend and a GitHub Pages workflow.

## Publish the frontend
1. Create a GitHub repository and upload the contents of this folder to its root.
2. In Settings → Pages, select GitHub Actions as the deployment source.
3. The workflow publishes `index.html` and GitHub shows the resulting URL.

## Scramjet status
This package does **not** include a running Scramjet engine or transport server. A real Scramjet deployment needs server-side components and service-worker configuration; GitHub Pages alone is static hosting and cannot provide the full proxy backend. See:
- https://github.com/MercuryWorkshop/scramjet
- https://docs.titaniumnetwork.org/proxies/scramjet/

This frontend is suitable as a visual starting point for an authorized deployment. It currently opens regular links in a new tab and does not proxy requests.
